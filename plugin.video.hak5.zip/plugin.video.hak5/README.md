# hak5

Kodi/XBMC video plugin containing
- Hak5: Weekly dose of Technolust
- Threat Wire: Security, Privacy, and Internet Freedom News
- TekThing
- HakTip
- Metasploit Minute

To build .zip that can be installed to Kodi:

    git archive --prefix=plugin.video.hak5/ -o plugin.video.hak5.zip HEAD
