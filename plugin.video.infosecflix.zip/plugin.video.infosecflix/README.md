# InfosecFlix: Hacker Presentations

Kodi/XBMC plugin with presentations from all the hacker conferences. (HOPE coming soon)

To build .zip that can be installed to Kodi:

    git archive --prefix=plugin.video.infosecflix/ -o plugin.video.infosecflix.zip HEAD

